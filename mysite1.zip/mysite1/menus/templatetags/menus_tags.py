"""menus/templatetags/menus_tags.py"""
from django import template

from ..models import Menu

register = template.Library()


@register.simple_tag()
def get_menu(slug):
    return Menu.objects.filter(slug=slug).first()


# @register.filter(title='replace')
# def replace(value):
#   return value.replace()
# my_str = 'a   b c   d e                                                                                                              f'

# result = re.sub(r'\s+', '', my_str)

